
<?php $__env->startSection('contenido'); ?>

<div class="container mt-4">

	<h2>Registrar Producto</h2>

	<form action="/productos" method="POST">
	<?php echo csrf_field(); ?>
		<div class="mb-3">
			<label for="" class="form-label">ID</label>
			<input type="number" id="id" name="id" step="any"  tabindex="1" class="form-control" >
		</div>
		<div class="mb-3">
			<label for="" class="form-label">Nombre</label>
			<input type="text" id="nombre" name="nombre" tabindex="2" class="form-control" >
		</div>
		<div class="mb-3">
			<label for="" class="form-label">Descripción</label>
			<input type="text" id="descripcion" name="descripcion" tabindex="3" class="form-control" >
		</div>
		<div class="mb-3">
			<label for="" class="form-label">Origen</label>
			<input type="number" id="origen" name="origen" step="any" tabindex="4" class="form-control" >
		</div>
		<a href="/productos" class="btn btn-secondary" tabindex="5">Cancelar</a>
		<button type="submit" class="btn btn-primary" tabindex='6'>Guardar</button>
	</form>
</div>
<div class="mt-2">
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Joseph\Desktop\Mercosur\Proyect-Mercosur\resources\views/Producto/create.blade.php ENDPATH**/ ?>

<?php $__env->startSection('contenido'); ?>
<section style="background-color:rgb(235, 241, 255 ) ;">
    <div class="container" >
    <div class="row">
        <div class="col-sm-6" >
   
        <strong><h2 class="text-center" style="font-family: 'Mate SC', serif;">Relaciones Diplomaticas</h2></strong>
        <br>
            <a href="/diplomaticas"><img src="assets/img/relaciones.jpg" class="img-fluid" width="650"></a>
            <p></p>
        </div>
        <div class="col-sm-6">
      
               <strong><h2 class="text-center"  style="font-family: 'Mate SC', serif;" >Relaciones Comerciales</h2></strong>
               <br>
            <a href="/comerciales"><img src="assets/img/comercial.png" class="img-fluid" width="650"></a>
        </div>
    </div>
</div>
</section>
<section class="text-center">
<div class="container-fluid">
    <div class="row">
 <div class="col-sm-6" >
    <h3>Régimen de Origen del MERCOSUR</h3>
    <div class="accordion" id="accordionPanelsStayOpenExample">
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingOne">
      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
        Capítulo I: Definiciones
      </button>
    </h2>
    <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse show" aria-labelledby="panelsStayOpen-headingOne">
      <div class="accordion-body">
     Artículo 1: Definición
El presente Régimen define las normas de origen del MERCOSUR, las disposiciones y las decisiones administrativas a ser aplicadas por los Estados Partes a los efectos de:

Calificación y determinación del producto originario;
Emisión de los certificados de origen;
Verificación y Control; y
Sanciones por adulteración o falsificación de los certificados de origen o por no cumplimiento de los procesos de verificación y control.
Texto según el artículo 1º de la Decisión CMC Nº 1/2009 "RÉGIMEN DE ORIGEN MERCOSUR", de fecha 23/07/2009, vigente desde el 27/06/2015
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingTwo">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="false" aria-controls="panelsStayOpen-collapseTwo">
        Capítulo II: Ámbito de aplicación
      </button>
    </h2>
    <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingTwo">
      <div class="accordion-body">
       Artículo 2: Vigencia
Hasta el 31 de diciembre de 2023, los Estados Partes podrán requerir el cumplimiento del Régimen de Origen del MERCOSUR para todo el comercio intrazona.

Texto con las modificaciones del artículo 1º de la Decisión CMC Nº 31/2015 "RÉGIMEN DE ORIGEN MERCOSUR", de fecha 16/07/2015, vigente desde el 19/09/201
      </div>
    </div>
  </div>
  <div class="accordion-item">
    <h2 class="accordion-header" id="panelsStayOpen-headingThree">
      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="false" aria-controls="panelsStayOpen-collapseThree">
       Capítulo III: Requisitos de origen
      </button>
    </h2>
    <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse" aria-labelledby="panelsStayOpen-headingThree">
      <div class="accordion-body">
        Artículo 3: Productos originarios
Serán considerados originarios:
Los productos totalmente obtenidos:
productos del reino vegetal cosechados o recolectados en el territorio de una o más Partes;
animales vivos, nacidos y criados en el territorio de una o más Partes;
productos obtenidos de animales vivos en el territorio de una o más Partes;
productos obtenidos de la caza, captura con trampas, pesca realizada en el territorio, o en sus aguas territoriales y zonas económicas exclusivas, de una o más Partes;
minerales y otros recursos naturales no incluidos en los subpárrafos i) a iv) extraídos u obtenidos en el territorio de una o más Partes;
      </div>
    </div>
  </div>
</div>
    </div>
        <div class="col-sm-6">
    <h3>Red de acuerdos Comerciales del MERCOSUR</h3>
    <img src="assets/img/acuerdos.png " class="img-fluid" width="500">
    <img src="assets/img/acuerdos2.png " class="img-fluid" width="500">
        </div>
</div> 
</div>
</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyect-Mercosur\resources\views/relaciones.blade.php ENDPATH**/ ?>
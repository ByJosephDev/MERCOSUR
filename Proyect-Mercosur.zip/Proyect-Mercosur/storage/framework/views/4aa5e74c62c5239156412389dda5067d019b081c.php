


<?php $__env->startSection('contenido'); ?>

<div class="container contenedor">
    <a href="diplomaticas/create" class="btn btn-success btn-large">Registrar Diplomatica</a> 
</div>

<div class="container">

    <table class="table mt-4 table-borderless table-dark">
        <thead>
            <tr>
            <th scope="col">ID</th>
            <th scope="col">Nombre</th>
            <th scope="col">Origen</th>
            <th scope="col">Destino</th>
            <th scope="col">Fecha</th>
            <th scope="col">Descripción</th>
            <th scope="col">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $diplomaticas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diplomatica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($diplomatica->id); ?></td>
                <td><?php echo e($diplomatica->nombre); ?></td>
                <td><?php echo e($diplomatica->origen); ?></td>
                <td><?php echo e($diplomatica->destino); ?></td>
                <td><?php echo e($diplomatica->fecha); ?></td>
                <td><?php echo e($diplomatica->descripcion); ?></td>
                <td>
                    
                    <form action="<?php echo e(route ('diplomaticas.destroy',$diplomatica->id)); ?>" method="POST">
                    <a href="/diplomaticas/<?php echo e($diplomatica->id); ?>/edit" class="btn btn-secondary">Editar</a>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button  type="submit" class="btn btn-danger">Borrar</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Joseph\Desktop\Mercosur\Proyect-Mercosur\resources\views/Diplomatica/index.blade.php ENDPATH**/ ?>
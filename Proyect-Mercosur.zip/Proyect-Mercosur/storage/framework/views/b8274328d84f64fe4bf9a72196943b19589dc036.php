
<?php $__env->startSection('contenido'); ?>

<div class="container">

    <div class="row">
        <div class="col-6">
        
            <a href="/comerciales">Comerciales</a>
        </div>





        <div class="col-6">
            <a href="/diplomaticas">Diplomaticas</a>
        </div>

    </div>


</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Joseph\Desktop\Mercosur\Proyect-Mercosur\resources\views/relaciones.blade.php ENDPATH**/ ?>
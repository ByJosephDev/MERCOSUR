


<?php $__env->startSection('contenido'); ?>

<div class="container contenedor">
    <a href="paises/create" class="btn btn-success btn-large">Registrar País</a> 
</div>

<div class="container">

    <table class="table mt-4 table-borderless table-dark">
        <thead>
            <tr>
            <th scope="col">ID</th>
            <th scope="col">Nombre</th>
            <th scope="col">Descripción</th>
            <th scope="col">Presidente</th>
            <th scope="col">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($pais->id); ?></td>
                <td><?php echo e($pais->nombre); ?></td>
                <td><?php echo e($pais->descripcion); ?></td>
                <td><?php echo e($pais->presidente); ?></td>
                <td>
                    <form action="<?php echo e(route ('paises.destroy',$pais->id)); ?>" method="POST">
                        <a href="/paises/<?php echo e($pais->id); ?>/edit" class="btn btn-secondary">Editar</a>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button  type="submit" class="btn btn-danger">Borrar</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyect-Mercosur (3)\Proyect-Mercosur\resources\views/Pais/index.blade.php ENDPATH**/ ?>
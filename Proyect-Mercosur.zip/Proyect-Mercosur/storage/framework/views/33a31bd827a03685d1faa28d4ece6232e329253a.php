


<?php $__env->startSection('contenido'); ?>

<div class="container contenedor">
    <a href="comerciales/create" class="btn btn-success btn-large">Registrar Comercial</a> 
</div>

<div class="container">

    <table class="table mt-4 table-borderless table-dark">
        <thead>
            <tr>
            <th scope="col">ID</th>
            <th scope="col">Nombre</th>
            <th scope="col">Origen</th>
            <th scope="col">Destino</th>
            <th scope="col">Fecha</th>
            <th scope="col">Descripción</th>
            <th scope="col">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $comerciales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comercial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($comercial->id); ?></td>
                <td><?php echo e($comercial->nombre); ?></td>
                <td><?php echo e($comercial->origen); ?></td>
                <td><?php echo e($comercial->destino); ?></td>
                <td><?php echo e($comercial->fecha); ?></td>
                <td><?php echo e($comercial->descripcion); ?></td>
                <td>
                    
                    <form action="<?php echo e(route ('comerciales.destroy',$comercial->id)); ?>" method="POST">
                    <a href="/comerciales/<?php echo e($comercial->id); ?>/edit" class="btn btn-secondary">Editar</a>
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button  type="submit" class="btn btn-danger">Borrar</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Joseph\Desktop\Mercosur\Proyect-Mercosur\resources\views/Comercial/index.blade.php ENDPATH**/ ?>
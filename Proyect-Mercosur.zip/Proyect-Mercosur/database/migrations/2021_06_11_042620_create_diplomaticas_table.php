<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDiplomaticasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('diplomaticas', function (Blueprint $table) {
            $table->id('id');
            $table->string('nombre');
            $table->unsignedBigInteger('origen');
            $table->unsignedBigInteger('destino');
            $table->string('fecha');
            $table->string('descripcion');
            
            $table->foreign('origen')->references('id')->on('pais');
            $table->foreign('destino')->references('id')->on('pais');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('diplomaticas');
    }
}

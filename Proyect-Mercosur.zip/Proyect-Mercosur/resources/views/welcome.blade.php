@extends('layout.layout')
@section('contenido')

<section id="hero" class="d-flex flex-column justify-content-end align-items-center">
    <div id="heroCarousel" data-bs-interval="5000" class="container carousel carousel-fade" data-bs-ride="carousel">

      <div class="carousel-item active">
        <div class="carousel-container">
          <p class="animate__animated fanimate__adeInUp"></p>
        </div>
      </div>

    </div>

    <svg class="hero-waves" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 24 150 28 " preserveAspectRatio="none">
      <defs>
        <path id="wave-path" d="M-160 44c30 0 58-18 88-18s 58 18 88 18 58-18 88-18 58 18 88 18 v44h-352z">
      </defs>
      <g class="wave1">
        <use xlink:href="#wave-path" x="50" y="3" fill="rgba(25, 42, 86,0.5)">
      </g>
      <g class="wave2">
        <use xlink:href="#wave-path" x="50" y="0" fill="rgba(68, 189, 50,0.5)">
      </g>
      <g class="wave3">
        <use xlink:href="#wave-path" x="50" y="9" fill="rgb(230, 237, 251 )">
      </g>
    </svg>

  </section>
    
    
  <section style="background-color: rgb(230, 237, 251 );"> 
    <div class="container-fluid">
        <div class="row">

            <div class="col-sm-6 ">

             <h2 class="mt-2" style="text-align: center;">  ¿Qué es MERCOSUR?</h2>
             <br>
             <p class="texto">El Mercado Común del Sur (MERCOSUR) es un proceso de integración regional instituido inicialmente por Argentina, Brasil, Paraguay y Uruguay al cual en fases posteriores se han incorporado Venezuela* y Bolivia, ésta última en proceso de adhesión.
                Sus idiomas oficiales de trabajo son el español y el portugués. La versión oficial de los documentos de trabajo será la del idioma del país sede de cada reunión. A partir del 2006, por medio de la Decisión CMC Nº 35/06, se incorporó al guaraní como uno de los idiomas del Bloque.
                El MERCOSUR es un proceso abierto y dinámico. Desde su creación tuvo como objetivo principal propiciar un espacio común que generara oportunidades comerciales y de inversiones a través de la integración competitiva de las economías nacionales al mercado internacional.
             </p>
            </div>
            
            <div class="col-sm-6">
           
            <img class="img-fluid" width="670"  src="assets/img/gente.png">
            
            </div>
        </div>
    
    </div>
  </section>
  
    <section class="" style="background-color:rgb(254, 254, 254 
 ) ;">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6">
            <img src="assets/img/gente2.jpg" class="p-5 img-fluid
            " width="700">
          </div>
          <div class="col-sm-6 bg-light p-5" >
            <h2 class="text-align text-secondary">Objetivos</h2>
            <br>
          <ul>
          <li class=" "  ><p class="ml-5 mr-5" > La libre circulación de bienes, servicios y factores productivos entre los países, a través, entre otros, de la eliminación de los derechos aduaneros y restricciones no arancelarias a la circulación de mercaderías y de cualquier otra medida equivalente.</p></li>
          <li class="">
            <p>El establecimiento de un arancel externo común y la adopción de una política comercial común con relación a terceros Estados o agrupaciones de Estados y la coordinación de posiciones en foros económicos-comerciales regionales e internacionales.</p>
          </li>
           <li class="">
            <p>La coordinación de políticas macroeconómicas y sectoriales entre los Estados Partes: de comercio exterior, agrícola, industrial, fiscal, monetaria, cambiaria y de capitales, de servicios, aduanera, de transportes y comunicaciones y otras que se acuerden, a fin de asegurar condiciones adecuadas de competencia entre los Estados Partes.</p>
          </li>
           <li class="">
            <p>El compromiso de los Estados Partes de armonizar sus legislaciones en las áreas pertinentes, para lograr el fortalecimiento del proceso de integración</p>
          </li>

          </ul>
          
          
                 
          </div>
        </div>
        
      </div>
    </section>
  <section  style="background-color: rgb(230, 237, 251 );">
    <div class="container-fluid">
      <div class="row"><div class="col-md-12">
       <strong><h2  style="font-family: 'Mate SC', serif; text-align: center;">Paises del MERCOSUR</h2></strong> 
        <br>
        <br>
        <img src="assets/img/paises.png" class="img-fluid p-5" style=" background-size: 100%; background-image: unset;">
      </div></div> 
    </div>
  </section>
  <footer class="" style="background-color:rgb(192, 196, 203 
);">
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3">
          <img src="assets/img/centro.png" class="p-5 m-5" width="300">
          
        </div>
        <div class="col-sm-3">
          <br>
          <br>
          <ul>
            <li>
              <h4>Contacto</h4>
Dr. Luis Piera 1992 – Piso 1 Edificio MERCOSUR Montevideo, Uruguay CP 11200

</li>
<li>(+598) 2412-9024 – Fax: (+598) 2410 0958 / 2418 0557</li>
<li>Consultas o dudas</li>
          </ul>
        </div>
        <div class="col-sm-3">
          <br>
          <br>
          <h4>Recibe novedades</h4>
          <form>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Nombre</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
    <div id="emailHelp" class="form-text"></div>
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Correo</label>
    <input type="password" class="form-control" id="exampleInputPassword1">
  </div>
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Recuerdamelo</label>
  </div>
  <button type="submit" class="btn btn-primary">Enviar</button>
</form>
          
        </div>
        <div class="col-sm-3">
          <br><br>
          <h4>Enalces de interes</h4>
          <ul><li>Trabajo</li>
            <li>Mapa del sitio</li>
            <li>Visita</li></ul>
        </div>
      </div>
      
    </div>
    <br><br>
  </footer>
  

@endsection

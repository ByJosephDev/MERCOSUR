@extends('layout.layout')
@section('contenido')

<div class="container contenedor">
    <a href="paises/create" class="btn btn-success btn-large">Registrar País</a> 
</div>
<div class="container">
    <table class="table mt-4 table-borderless table-dark">
        <thead>
            <tr>
            <th scope="col">ID</th>
            <th scope="col">Nombre</th>
            <th scope="col">Descripción</th>
            <th scope="col">Presidente</th>
            <th scope="col">Editar</th>
            <th scope="col">Eliminar</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($paises as $pais)
            <tr>
                <td>{{$pais->id}}</td>
                <td>{{$pais->nombre}}</td>
                <td>{{$pais->descripcion}}</td>
                <td>{{$pais->presidente}}</td>
                <td><a href="/paises/{{ $pais->id }}/edit" class="btn btn-secondary">Modificar</a></td>
                <td>
                    <form action="{{ route ('paises.destroy',$pais->id)}}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button  type="submit" class="btn btn-danger">Desvincular</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection



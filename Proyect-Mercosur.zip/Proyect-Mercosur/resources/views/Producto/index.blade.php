@extends('layout.layout')


@section('contenido')

<div class="container contenedor">
    <a href="productos/create" class="btn btn-success btn-large">Registrar Producto</a> 
</div>

<div class="container">

    <table class="table mt-4 table-borderless table-dark">
        <thead>
            <tr>
            <th scope="col">ID</th>
            <th scope="col">Nombre</th>
            <th scope="col">Descripción</th>
            <th scope="col">Origen</th>
            <th scope="col">Editar</th>
            <th scope="col">Eliminar</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($productos as $producto)
            <tr>
                <td>{{$producto->id}}</td>
                <td>{{$producto->nombrep}}</td>
                <td>{{$producto->descripcion}}</td>
                <td>{{$producto->nombre}}</td>
                <td><a href="/productos/{{ $producto->id }}/edit" class="btn btn-secondary">Modificar</a></td>
                <td>
                    <form action="{{ route ('productos.destroy',$producto->id)}}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button  type="submit" class="btn btn-danger">Desvincular</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>

</div>
@endsection
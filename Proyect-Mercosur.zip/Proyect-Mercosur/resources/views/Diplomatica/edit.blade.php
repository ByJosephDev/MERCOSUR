@extends('layout.layout')
@section('contenido')

<div class="container mt-4">

	<h2>Editar Diplomatica</h2>

	<form action="/diplomaticas/{{$diplomatica->id}}" method="POST">
	@csrf
	@method('PUT')
		<div class="mb-3">
			<label for="" class="form-label">ID</label>
			<input type="number" id="id" name="id"  step="any" tabindex="1" class="form-control" value="{{$diplomatica->id}}">
		</div>
		<div class="mb-3">
			<label for="" class="form-label">Nombre</label>
			<input type="text" id="nombre" name="nombre" tabindex="2" class="form-control" value="{{$diplomatica->nombre}}">
		</div>
        <div class="mb-3">
			<label for="" class="form-label">Origen</label>
			<input type="number" id="origen" name="origen" step="any" tabindex="3" class="form-control" value="{{$diplomatica->origen}}">
		</div>
        <div class="mb-3">
			<label for="" class="form-label">Destino</label>
			<input type="number" id="destino" name="destino" step="any" tabindex="4" class="form-control" value="{{$diplomatica->destino}}">
		</div>
        <div class="mb-3">
			<label for="" class="form-label">Fecha</label>
			<input type="text" id="fecha" name="fecha" tabindex="5" class="form-control" value="{{$diplomatica->fecha}}">
		</div>
		<div class="mb-3">
			<label for="" class="form-label">Descripción</label>
			<input type="text" id="descripcion" name="descripcion" tabindex="6" class="form-control" value="{{$diplomatica->descripcion}}">
		</div>
		<a href="/diplomaticas" class="btn btn-secondary" tabindex="7">Cancelar</a>
		<button type="submit" class="btn btn-primary" tabindex='8'>Guardar</button>
	</form>

</div>
<div class="mt-2">
</div>


@endsection
@extends('layout.layout')


@section('contenido')

<div class="container contenedor">
    <a href="diplomaticas/create" class="btn btn-success btn-large">Registrar Diplomatica</a> 
</div>

<div class="container">

    <table class="table mt-4 table-borderless table-dark">
        <thead>
            <tr>
            <th scope="col">ID</th>
            <th scope="col">Nombre</th>
            <th scope="col">Origen</th>
            <th scope="col">Destino</th>
            <th scope="col">Fecha</th>
            <th scope="col">Descripción</th>
            <th scope="col">Editar</th>
            <th scope="col">Eliminar</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($diplomaticas as $diplomatica)
            <tr>
                <td>{{$diplomatica->id}}</td>
                <td>{{$diplomatica->nombred}}</td>
                <td>{{$diplomatica->do}}</td>
                <td>{{$diplomatica->dd}}</td>
                <td>{{$diplomatica->fecha}}</td>
                <td>{{$diplomatica->descripcion}}</td>
                <td><a href="/diplomaticas/{{ $diplomatica->id }}/edit" class="btn btn-secondary">Modificar</a></td>
                <td>
                    
                    <form action="{{ route ('diplomaticas.destroy',$diplomatica->id)}}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button  type="submit" class="btn btn-danger">Desvincular</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>

</div>
@endsection
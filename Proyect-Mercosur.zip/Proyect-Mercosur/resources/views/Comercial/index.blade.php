@extends('layout.layout')


@section('contenido')

<div class="container contenedor">
    <a href="comerciales/create" class="btn btn-success btn-large">Registrar Comercial</a> 
</div>

<div class="container">

    <table class="table mt-4 table-borderless table-dark">
        <thead>
            <tr>
            <th scope="col">ID</th>
            <th scope="col">Nombre</th>
            <th scope="col">Producto</th>
            <th scope="col">Origen</th>
            <th scope="col">Destino</th>
            <th scope="col">Fecha</th>
            <th scope="col">Descripción</th>
            <th scope="col">Editar</th>
            <th scope="col">Eliminar</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($comerciales as $comercial)
            <tr>
                <td>{{$comercial->id}}</td>
                <td>{{$comercial->nombred}}</td>
                <td>{{$comercial->nombrep}}</td>
                <td>{{$comercial->do}}</td>
                <td>{{$comercial->dd}}</td>
                <td>{{$comercial->fecha}}</td>
                <td>{{$comercial->descripcion}}</td>
                <td><a href="/comerciales/{{ $comercial->id }}/edit" class="btn btn-secondary">Modificar</a></td>
                <td>
                    <form action="{{ route ('comerciales.destroy',$comercial->id)}}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button  type="submit" class="btn btn-danger">Desvincular</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>

</div>
@endsection
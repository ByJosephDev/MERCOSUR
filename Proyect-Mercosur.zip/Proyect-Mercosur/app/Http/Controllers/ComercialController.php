<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Comercial;
use DB;
class ComercialController extends Controller
{
    public function index()
    {
        $comerciales = DB::table('comercials')
        ->join('pais','comercials.origen', '=','pais.id')
        ->join('pais as pais2','comercials.destino', '=','pais2.id')
        ->join('productos','comercials.producto', '=','productos.id')
        ->select('comercials.id','comercials.nombre as nombred','productos.nombre as nombrep','pais.nombre as do','pais2.nombre as dd','comercials.fecha','comercials.descripcion')
        ->get(); 
        return view('Comercial.index')->with('comerciales',$comerciales);
    }
    public function create()
    {
        return view('Comercial.create');
    }
    public function store(Request $request)
    {
        $comerciales = new Comercial();
        $comerciales->id = $request->get('id');
        $comerciales->nombre= $request->get('nombre');
        $comerciales->producto= $request->get('producto');
        $comerciales->origen = $request->get('origen');
        $comerciales->destino = $request->get('destino');
        $comerciales->fecha = $request->get('fecha');
        $comerciales->descripcion = $request->get('descripcion');
        
        $comerciales->save();
        return redirect('comerciales');
    }
    public function edit($id)
    {
        $comercial = Comercial::find($id);
        return view('Comercial.edit')->with('comercial',$comercial);
    }
    public function update(Request $request, $id)
    {
        $comercial = Comercial::find($id);
        $comercial->id= $request->get('id');
        $comercial->nombre = $request->get('nombre');
        $comercial->producto = $request->get('producto');
        $comercial->origen = $request->get('origen');
        $comercial->destino = $request->get('destino');
        $comercial->fecha= $request->get('fecha');
        $comercial->descripcion= $request->get('descripcion');
        
        $comercial->save();
        return redirect('comerciales');
    }

    public function destroy($id)
    {
        $comercial = Comercial::find($id);
        $comercial->delete();
        return redirect('comerciales');
    }
}



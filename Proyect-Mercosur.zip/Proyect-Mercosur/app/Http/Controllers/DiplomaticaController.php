<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Diplomatica;

use DB;

class DiplomaticaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $diplomaticas = DB::table('diplomaticas')
        ->join('pais','diplomaticas.origen', '=','pais.id')
        ->join('pais as pais2','diplomaticas.destino', '=','pais2.id')
        ->select('diplomaticas.id','diplomaticas.nombre as nombred','pais.nombre as do','pais2.nombre as dd','diplomaticas.fecha','diplomaticas.descripcion')
        ->get(); 
        return view('Diplomatica.index')->with('diplomaticas',$diplomaticas);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('Diplomatica.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $diplomaticas = new Diplomatica();
        $diplomaticas->id = $request->get('id');
        $diplomaticas->nombre= $request->get('nombre');
        $diplomaticas->origen = $request->get('origen');
        $diplomaticas->destino = $request->get('destino');
        $diplomaticas->fecha = $request->get('fecha');
        $diplomaticas->descripcion = $request->get('descripcion');
        
        $diplomaticas->save();

        return redirect('diplomaticas');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $diplomatica = Diplomatica::find($id);
        return view('Diplomatica.edit')->with('diplomatica',$diplomatica);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $diplomatica = Diplomatica::find($id);
        $diplomatica->id= $request->get('id');
        $diplomatica->nombre = $request->get('nombre');
        $diplomatica->origen = $request->get('origen');
        $diplomatica->destino = $request->get('destino');
        $diplomatica->fecha= $request->get('fecha');
        $diplomatica->descripcion= $request->get('descripcion');
        

        $diplomatica->save();

        return redirect('diplomaticas');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $diplomatica = Diplomatica::find($id);
        $diplomatica->delete();
        return redirect('diplomaticas');
    }
}

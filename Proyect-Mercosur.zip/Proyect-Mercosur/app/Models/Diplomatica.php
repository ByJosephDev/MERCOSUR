<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Diplomatica extends Model
{
    use HasFactory;

    protected $fillable = ['nombre','origen','destino','fecha','descripcion'];

}
